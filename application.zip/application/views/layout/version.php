<!-- page content -->
<div class="right_col" role="main">
  <div class="row">
    <div class="col-md-12 col-sm-12 col-xs-12">
      <div class="x_panel">
        <div class="x_title">
          <h2>About<small>Developer</small></h2>
          <div class="clearfix"></div>
        </div>
        <div class="x_content">
          <h4>
         <b>   I am a full-time freelancer with a background in PHP, Codeignitor, Laravel and Android App Development. Serving over 50 awesome clients across the globe, I have a passion for making my clients shine with my Development expertise. Feel free to play my sample reel, following is my portfolio which is opened for Students for their Academic Project and for Professionals at Commercial corner.<br>
          </b></h4>
          <br>
          <h3>
      <b>    Web Applications</b>
          </h3>
          <ul><h2 style="color:darkorchid"> 
            <li>Advanced Online Examination System Admin Panel and Students Panel</li>
            <li>Garment Management System</li>
            <li>Hospital Management System</li>
            <li>Billing and Stock Management System</li>
            <li>Gym Manageemnt System</li>
            <li>Vaccination Management System</li>
            <li>Online Food Delivery - Front End with Admin Panel</li>
            <li>Business ERP System</li>
            <li>Multi level Marketing System</li>
            <li>Appoitment Management System</li>
            <li>Pharmacy Management System</li>
            <li>School Management System</li>
            <li>Phone Store Management System</li>
            <li>Software Development Office</li></h2>

          </ul> <br>
<h3>
           <b>Android Applications
         </b> </h3>
          <ul><h2 style="color:red"> 
            <li>Online Examination Android App</li>
            <li>Task Management App</li>

            <li>Staff Salary App</li>
            <li>Online Food Ordering App</li>
            <li>Android App like Just Dial</li></h2>
  
            
          </ul>

          <br>
<h3>
           <b>dot net Applications
         </b> </h3>
          <ul><h2 style="color:GREEN"> 
            <li>Subscription Management System for .net Application in Realtime</li>
            <li>Notification application if someone join Pendrive to system</li>
            <li>Employee PC Monitoring system get all activity report on Boss PC</li>  
            
          </ul>
<br><br>
<h3>
           <b>Contact me at mayuri.infospace@gmail.com
         </b> </h3>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- /page content -->