<!--page content -->
<div class="right_col" role="main">
<div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Sell<small>Section</small></h2>
                    <a href="<?php echo base_url();?>sell/add"><button class="btn btn-primary pull-right">Add New</button></a>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
					
                    <table id="datatable-responsive" class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0" width="100%">
                      <thead>
                        <tr>
                          <th>Customer name</th>
                          <th>Email</th>
                          <!-- <th>Image</th> -->
                          <th>Phone</th>
                          <th>Action</th>
                        </tr>
                      </thead>
                    </table>
					
					
                  </div>
                </div>
              </div>
</div>
<!-- /page content