<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Buy_model extends CI_Model
{
	
	
	public function __construct(){
        parent:: __construct();
    }

    public function getPhones()
    {
      
    }
    public function add($phone_array)
    {
      
    }
    public function getphone($id)
    {
      
    }
    public function update($phone_array)
    {
    	
    }
   public function deletephone($id)
  {

    
  }

 }
